export const genderMap = {
  Male: 'Чоловіча',
  Female: 'Жіноча',
};